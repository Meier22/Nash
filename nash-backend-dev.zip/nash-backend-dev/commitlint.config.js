module.exports = {
  rules: {
    'type-empty': [2, 'never'],
    'type-enum': [
      2,
      'always',
      [
        'user-service',
        'auth-service',
        'order-service',
        'segment-service',
        'cross-services',
        'documentation',
        'configuration',
        'infrastructure'
      ]
    ],
    'scope-empty': [2, 'never'],
    'scope-enum': [2, 'always', ['add', 'fix', 'remove', 'update', 'refactor']],
    'subject-empty': [2, 'never']
  },
  parserPreset: {
    parserOpts: {
      headerPattern: /^\[(.*)\]\ - (.*) - (.*)$/,
      headerCorrespondence: ['type', 'scope', 'subject']
    }
  }
};

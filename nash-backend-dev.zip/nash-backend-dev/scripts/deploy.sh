# Build step

yarn install --frozen-lockfile
cd services
cd auth
yarn install --frozen-lockfile && yarn deploy
cd ../orders
yarn install --frozen-lockfile  && yarn deploy
cd ../segments
yarn install --frozen-lockfile  && yarn deploy
cd ../users
yarn install --frozen-lockfile  && yarn deploy
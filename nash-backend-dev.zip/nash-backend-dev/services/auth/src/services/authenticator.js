import * as cognito from './../interfaces/cognito';
import { Notification } from './../../../../libs/infrastructure';
import { updateUser } from './../../../users/src/services/users';
import {
  getUserByEmail
} from './../../../users/src/interfaces/storage';

export const recoverPassword = async ({ recoveryCode, newPassword, email }) => {
  return await cognito.recoverPassword(recoveryCode, newPassword, email);
};

export const sendPasswordRecoveryCode = async ({ email }) => {
  return await cognito.sendPasswordRecoveryCode(email);
};

export const renewSession = async ({ email, refreshToken }) => {
  const result = await cognito.renewSession(email, refreshToken);
  return {
    token: result.idToken.jwtToken,
    refreshToken: result.refreshToken.token
  };
};

export const signInUser = async ({ email, password }) => {
  const result = await cognito.signInUser(email, password);
  const userSignedIn = await getUserByEmail(email);

  return {
    token: result.idToken.jwtToken,
    refreshToken: result.refreshToken.token,
    profile: userSignedIn
  };
};

export const signUpUser = async (payloadReceived) => {
  const { email, password } = payloadReceived;

  const result = await cognito.signUpUser(email, password);

  const notification = new Notification(
    process.env.USER_SIGNED_UP_TOPIC_ARN,
    { ...payloadReceived, _id: result },
    undefined,
    {
      deduplicationId: payloadReceived.email,
      groupId: `USER_SIGNED_UP`
    }
  );

  await notification.send();
  return result;
};

export const changeUserEmail = async (owner, newEmail) => {
  await cognito.changeUserEmail(owner, newEmail);
  const dataToUpdate = {
    email: newEmail
  };
  return await updateUser(dataToUpdate, owner);
};
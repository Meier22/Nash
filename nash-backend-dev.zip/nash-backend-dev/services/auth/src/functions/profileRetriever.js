import { Handler } from './../../../../libs/infrastructure';
import { getUserById } from '../../../users/src/interfaces/storage';

export const handle = new Handler('Profile retriever')
  .handle(async (event, context) => {
    return await getUserById(event.authorizer.principalId);
  });
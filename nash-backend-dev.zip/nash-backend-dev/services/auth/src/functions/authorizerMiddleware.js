import axios from 'axios';
import jwt from 'jsonwebtoken';
import jwkToPem from 'jwk-to-pem';
import { loggerFactory } from './../../../../libs/infrastructure';

const logger = loggerFactory.getFrom('Authorizer');

const poolData = {
    UserPoolId: process.env.COGNITO_USER_POOL_ID,
    ClientId: process.env.COGNITO_CLIENT_ID,
    Region: process.env.AWS_ENVIRONMENT_REGION
};

const allowedEndpoints = (userId) => [
    `users/${userId}`,
    "/orders",
    "GET/v1/segments",
    "/me"
];

const buildIAMPolicy = (userId, effect, resource, context) => {
    console.log(`buildIAMPolicy ${userId} ${effect} ${resource}`);
    const policy = {
        principalId: userId,
        policyDocument: {
            Version: '2012-10-17',
            Statement: [
                {
                    Action: 'execute-api:Invoke',
                    Effect: effect,
                    Resource: resource,
                },
            ],
        },
        context,
    };
    return policy;
};

const downloadJwks = async (poolData) => await axios.get(`https://cognito-idp.${poolData.Region}.amazonaws.com/${poolData.UserPoolId}/.well-known/jwks.json`);

const convertJwkToPem = (keys) => {
    var pems = {};
    for (var i = 0; i < keys.length; i++) {
        var key_id = keys[i].kid;
        var modulus = keys[i].n;
        var exponent = keys[i].e;
        var key_type = keys[i].kty;
        var jwk = { kty: key_type, n: modulus, e: exponent };
        var pem = jwkToPem(jwk);
        pems[key_id] = pem;
    }

    return pems;
};

export const authorize = async (event, context, cb) => {
    logger.info(`Authorizing access to ${event.methodArn}`);
    if (event.authorizationToken) {
        const token = event.authorizationToken.substring(7);
        const response = await downloadJwks(poolData);
        const body = response.data;

        if (response.status === 200) {
            var pems = convertJwkToPem(body.keys);

            var decodedJwt = jwt.decode(token, { complete: true });

            if (!decodedJwt) {
                logger.error(`The token received is invalid`);
                cb('Unauthorized');
            }

            var kid = decodedJwt.header.kid;
            var pem = pems[kid];
            if (!pem) {
                logger.error(`The token received is invalid`);
                cb('Unauthorized');
            }


            jwt.verify(token, pem, function (err, payload) {
                if (err) {
                    logger.error(`The token received is invalid`);
                    cb('Unauthorized');
                } else {
                    logger.info(`Token decoded successfully ${payload}`);
                    const allowedEndpointsForThisUser = allowedEndpoints(payload['cognito:username']);
                    logger.info(`Analyzing if resource is within the following allowed endpoints ${allowedEndpointsForThisUser}`);
                    const shouldAccess = allowedEndpointsForThisUser.some(allowedEndpoint => event.methodArn.includes(allowedEndpoint));
                    if (!shouldAccess) {
                        logger.error(`The user is not allowed to access this resource`);
                        cb('Unauthorized');
                    }
                    const authorizerContext = { token: JSON.stringify(payload) };
                    const policyDocument = buildIAMPolicy(payload.sub, 'Allow', '*', authorizerContext);
                    cb(null, policyDocument);
                }
            });
        } else {
            logger.error(`Could not download JWKs`);
            cb('Unauthorized');
        }
    } else {
        logger.error(`Could not find any Authorization token in header`);
        cb('Unauthorized');
    }
};
import { Handler } from './../../../../libs/infrastructure';
import customErrorParser from './../../../../libs/constants';
import { signInUser } from './../services/authenticator';

export const handle = new Handler('User Authenticator')
  .withHttpPayloadParser()
  .withCustomErrorParser(customErrorParser)
  .handle(async (event, context) => {
    return await signInUser(event.payload);
  });

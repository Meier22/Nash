import { Handler } from './../../../../libs/infrastructure';
import { changeUserEmail } from './../services/authenticator';

export const handle = new Handler('Change User Email')
    .withHttpContextParser()
    .withHttpPayloadParser()
    .handle(async (event, context) => {
        const owner = event.authorizer.principalId;
        const newEmail = event.payload.newEmail;
        return await changeUserEmail(owner, newEmail);
    });
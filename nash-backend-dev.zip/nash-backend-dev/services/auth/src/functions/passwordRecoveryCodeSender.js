import { Handler } from './../../../../libs/infrastructure';
import customErrorParser from './../../../../libs/constants';
import { sendPasswordRecoveryCode } from './../services/authenticator';

export const handle = new Handler('User Authenticator')
  .withHttpPayloadParser()
  .withCustomErrorParser(customErrorParser)
  .handle(async (event, context) => {
    return await sendPasswordRecoveryCode(event.payload);
  });

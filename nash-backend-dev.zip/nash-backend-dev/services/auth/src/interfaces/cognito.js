import { AuthenticationDetails, CognitoRefreshToken, CognitoUser } from 'amazon-cognito-identity-js';
import AWS from "aws-sdk";
import getUserPool from './userPoolConnector';

export const signUpUser = async (email, password) => {
  const userPool = await getUserPool();
  return new Promise((resolve, reject) => {
    userPool.signUp(email, password, null, null, (error, result) => {
      if (error) reject(error);
      resolve(result.userSub);
    });
  });
};

const signInCallbacks = (resolve, reject) => ({
  onSuccess: (result) => {
    return resolve(result);
  },
  onFailure: (error) => {
    reject(error);
  }
});

export const signInUser = async (email, password) => {
  const authenticationDetails = new AuthenticationDetails(
    { Username: email, Password: password }
  );

  const user = new CognitoUser({
    Username: email,
    Pool: await getUserPool()
  });

  return new Promise((resolve, reject) => {
    user.authenticateUser(
      authenticationDetails,
      signInCallbacks(resolve, reject)
    );
  });
};

export const renewSession = async (email, refreshToken) => {
  const oldRefreshToken = new CognitoRefreshToken({
    RefreshToken: refreshToken
  });

  const user = new CognitoUser({
    Username: email,
    Pool: await getUserPool()
  });

  return new Promise((resolve, reject) => {
    user.refreshSession(oldRefreshToken, (error, result) => {
      if (error) reject(error);
      resolve(result);
    });
  });
};

export const sendPasswordRecoveryCode = async (email) => {
  const user = new CognitoUser({
    Username: email,
    Pool: await getUserPool()
  });

  return new Promise((resolve, reject) => {
    user.forgotPassword({
      onSuccess: (data) => {
        resolve(`Password recovered from ${email}`);
      },
      onFailure: (error) => {
        reject(error);
      }
    });
  });
};

export const recoverPassword = async (recoveryCode, newPassword, email) => {
  const user = new CognitoUser({
    Username: email,
    Pool: await getUserPool()
  });

  return new Promise((resolve, reject) => {
    user.confirmPassword(recoveryCode, newPassword, {
      onSuccess: (data) => {
        resolve(`Password changed for user: ${email}`);
      },
      onFailure: (error) => {
        reject(error);
      }
    });
  });
};

export const changeUserEmail = async (owner, newEmail) => {
  const cognitoProvider = new AWS.CognitoIdentityServiceProvider();
  const pool = await getUserPool();
  const user = {
    UserAttributes: [
      {
        Name: 'email',
        Value: newEmail
      },
      {
        Name: 'email_verified',
        Value: 'true'
      }
    ],
    Username: owner,
    UserPoolId: pool.userPoolId
  };

  return new Promise((resolve, reject) => {
    cognitoProvider.adminUpdateUserAttributes(user, (err, data) => {
      if (err) reject(err);
      resolve();
    });
  });
};
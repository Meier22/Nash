import * as storage from './../interfaces/storage';
import { Notification } from './../../../../libs/infrastructure';
import { NotFoundError } from '../../../../libs/infrastructure/errorHandlers';

export const getAssociatedOrders = async (orderOwnerId, query) => {
  return await storage.getAssociatedOrders(orderOwnerId, query);
};

export const applyOfferToOrder = async (offerToCreate) => {
  const isOrderFound = await getOrderById(offerToCreate.order);
  if (!isOrderFound) throw new NotFoundError();

  const result = await storage.saveOffer(offerToCreate);
  const notification = new Notification(
    process.env.OFFER_SENT_TOPIC_ARN,
    result,
    undefined,
    {
      deduplicationId: result._id.toString(),
      groupId: result.order
    }
  );

  await notification.send();
  return result;
};

export const linkOfferToOrder = async (orderId, offer) => {
  return await storage.applyOfferToOrder(orderId, offer);
};

export const createOrder = async (orderToSave) => {
  const result = await storage.saveOrder(orderToSave);
  const notification = new Notification(
    process.env.ORDER_CREATED_TOPIC_ARN,
    result,
    {
      orderType: {
        DataType: 'String',
        StringValue: result.type
      }
    },
    {
      deduplicationId: result._id.toString(),
      groupId: result.owner
    }
  );

  await notification.send();
  return result;
};

export const getOrderById = async (orderId) => {
  return await storage.getOrderById(orderId);
};

export const updateOrder = async (orderId, orderOwnerId, propertiesToUpdate) => {
  const order = await getOrderById(orderId);
  if (!order) throw new NotFoundError();
  return await storage.updateOrder(orderId, orderOwnerId, propertiesToUpdate);
};

export const listOrdersBy = async (segmentId, parameters) => {
  return await storage.listOrdersBy(segmentId, parameters);
};

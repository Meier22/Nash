import { OrderModel, OfferModel } from './../../../../libs/models';
import { connectToDatabase } from './../../../../libs/infrastructure';

const WITHOUT_SENSITIVE_INFORMATION = '-owner';

export const saveOrder = async (orderToSave) => {
  await connectToDatabase();
  return OrderModel.create(orderToSave);
};

export const updateOrder = async (orderId, owner, propertiesToUpdate) => {
  await connectToDatabase();
  const filter = {
    owner,
    _id: orderId
  };
  return OrderModel.findOneAndUpdate(filter, propertiesToUpdate, {
    new: true,
    lean: true
  });
};

export const applyOfferToOrder = async (orderId, offer) => {
  await connectToDatabase();
  const filter = {
    _id: orderId
  };
  const update = {
    $addToSet: { offers: offer },
    $inc: { offersQuantity: 1 }
  };
  const options = {
    new: true
  };
  return OrderModel.findOneAndUpdate(filter, update, options);
};

export const getOrderById = async (orderId) => {
  await connectToDatabase();
  return OrderModel.findById(orderId).select(WITHOUT_SENSITIVE_INFORMATION).lean(true);
};

export const getAssociatedOrders = async (userId, parameters) => {
  await connectToDatabase();
  const preProcessedFilters = {
    owner: userId,
    ...parameters.filters
  };
  return {
    records: await OrderModel.find(preProcessedFilters)
      .skip(Number((parameters.page - 1) * parameters.limit))
      .limit(Number(parameters.limit))
      .sort(parameters.sort || '-submitDate')
      .lean(true),
    count: await OrderModel.count(preProcessedFilters)
  };
};

export const saveOffer = async (offerToSave) => {
  await connectToDatabase();
  return OfferModel.create(offerToSave);
};

export const listOrdersBy = async (segmentId, parameters) => {
  await connectToDatabase();
  const keywordToSearch = ((Object.values(parameters.filters)).toString()).replace(/[,]/g, " ").trimLeft();
  return OrderModel.find(
    { $text: { $search: keywordToSearch } },
    { score: { $meta: "textScore" } },
    {
      status: 'active',
      segmentAssociated: segmentId,
      type: parameters.type
    }
  )
    .sort({ score: { $meta: "textScore" } })
    .skip(Number((parameters.page - 1) * parameters.limit))
    .limit(Number(parameters.limit))
    .lean(true);
};
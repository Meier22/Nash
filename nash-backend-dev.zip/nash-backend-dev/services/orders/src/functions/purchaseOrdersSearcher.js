// TODO: remove from here, it is in orders
import { Handler } from './../../../../libs/infrastructure';
import { listOrdersBy } from './../services/orders';

export const handle = new Handler('PurchaseOrders Retriever by Segment')
  .withPathParametersPayloadParser()
  .withQueryStringParametersParser()
  .handle(async (event, context) => {
    return await listOrdersBy(event.path.segmentId, {
      ...event.query,
      type: 'PURCHASE'
    });
  });

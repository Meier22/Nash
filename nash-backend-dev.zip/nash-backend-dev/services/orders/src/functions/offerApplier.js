import { Handler } from './../../../../libs/infrastructure';
import { applyOfferToOrder } from './../services/orders';

export const handle = new Handler('Offer applier')
  .withPathParametersPayloadParser()
  .withHttpPayloadParser()
  .handle(async (event, context) => {
    return await applyOfferToOrder({ ...event.payload, order: event.path.orderId });
  });

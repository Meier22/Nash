import { Handler } from './../../../../libs/infrastructure';
import { updateOrder } from './../services/orders';

export const handle = new Handler('Order Updater')
  .withPathParametersPayloadParser()
  .withHttpPayloadParser()
  .withHttpContextParser()
  .handle(async (event, context) => {
    const orderId = event.path.orderId;
    const owner = event.authorizer.principalId;
    const propertiesToUpdate = event.payload;
    return await updateOrder(orderId, owner, propertiesToUpdate);
  });

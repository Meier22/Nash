import { Handler } from './../../../../libs/infrastructure';
import { getOrderById } from './../services/orders';

export const handle = new Handler('Order Retriever')
  .withPathParametersPayloadParser()
  .handle(async (event, context) => {
      return await getOrderById(event.path.orderId);
  });

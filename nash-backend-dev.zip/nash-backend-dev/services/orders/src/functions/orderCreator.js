import { Handler } from './../../../../libs/infrastructure';
import { createOrder } from './../services/orders';

export const handle = new Handler('Associated Order Creator')
  .withHttpPayloadParser()
  .withHttpContextParser()
  .handle(async (event, context) => {
    const orderToSave = { ...event.payload, owner: event.authorizer.principalId };
    return await createOrder(orderToSave);
  });
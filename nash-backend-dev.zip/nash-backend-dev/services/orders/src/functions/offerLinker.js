import { Handler } from './../../../../libs/infrastructure';
import { linkOfferToOrder } from './../services/orders';

export const handle = new Handler('Offer Linker')
  .withQueuePayloadParser()
  .handle(async (event, context) => {
    let { orderId, offer } = { ...event.message };
    return await linkOfferToOrder(orderId, offer);
  });
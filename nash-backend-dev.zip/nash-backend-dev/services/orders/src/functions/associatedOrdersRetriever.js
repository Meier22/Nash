import { Handler } from './../../../../libs/infrastructure';
import { getAssociatedOrders } from './../services/orders';

export const handle = new Handler('Associated Orders\' Retriever')
  .withQueryStringParametersParser()
  .withHttpContextParser()
  .handle(async (event, context) => {
    const owner = event.authorizer.principalId;
    return await getAssociatedOrders(owner, event.query);
  });
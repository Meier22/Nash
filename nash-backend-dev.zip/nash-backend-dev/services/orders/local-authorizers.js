const AWS = require("aws-sdk");
const locallyAuthorize = async (event, context) => {
  const lambda = new AWS.Lambda();
  const result = await lambda.invoke({
    FunctionName: "nash-auth-service-dev-authorizer",
    InvocationType: "RequestResponse",
    Payload: JSON.stringify({ ...event, authorizationToken: event.headers.Authorization }),
  }).promise();

  if (result.StatusCode === 200) {
    return JSON.parse(result.Payload);
  }

  throw Error("Authorizer error");
};

module.exports = { locallyAuthorize };
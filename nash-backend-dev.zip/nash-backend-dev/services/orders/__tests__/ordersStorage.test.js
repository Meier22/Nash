import * as mockingoose from 'mockingoose';
import { OrderModel } from './../../../libs/models/order';
import 'regenerator-runtime/runtime';
import * as sut from './../src/interfaces/storage';
import { connectToDatabase } from './../../../libs/infrastructure';

jest.mock('./../../../libs/infrastructure');

describe('Orders Storage should', () => {
    afterEach(() => {
        connectToDatabase.mockClear();
        mockingoose.resetAll();
    });

    const _doc = {
        _id: '59225c79-b3bb-4d1e-a10a-4f96e1884c4d',
        owner: "8de07744-1ed9-4da2-a9aa-a6c1ee6f5a95",
        segmentAssociated: "37b9995c-0b56-43b5-b741-f1f05da8f179",
        status: "active",
        type: "purchase",
        title: "Cabezas de Ganado Vacuno",
        ltitle: "cocechadora",
        offers: [],
        offersQuantity: 1,
        submitDate: "2021-07-11T00:00:00.000Z",
        dueDate: "2021-07-30T00:00:00.000Z",
        location: [
            "Argentina",
            "Buenos Aires",
            "Monte Grande"
        ],
        acceptedPaymentTypes: [
            "Tarjeta de crédito",
            "Transferencias",
            "Lira"
        ],
        description: "Vacas Angus",
        filteringPercentage: 50,
        products: [
            {
                id: 1,
                name: "Vacas",
                subSegmentAssociated: "e3269659-50e0-4a3a-b2dc-98bf66c46b34",
                description: "Tipo Angus",
                stock: {
                    unit: "unit",
                    originalQuantity: "100",
                    leftQuantity: "100"
                },
                multimedia: {
                    mimeType: "json",
                    uri: "http://localhost/image.png"
                }
            }
        ]
    };

    it('return saved order when calling storage.saveOrder', async () => {
        mockingoose(OrderModel).toReturn(_doc, 'save');

        const result = await sut.saveOrder(_doc);

        expect(JSON.parse(JSON.stringify(result))).toMatchObject(_doc);
    });

    it('call connectToDatabase when calling storage.saveOrder', async () => { 
        await sut.saveOrder(_doc);

        expect(connectToDatabase).toHaveBeenCalledTimes(1);
    });
});
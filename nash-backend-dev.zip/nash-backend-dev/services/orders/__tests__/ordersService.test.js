jest.mock('./../src/interfaces/storage', () => ({
    __esModule: true,
    getAssociatedOrders: jest.fn(),
    saveOffer: jest.fn().mockReturnValue({ _id: 'Default-Id-Test' }),
    saveOrder: jest.fn().mockReturnValue({ _id: 'Default-Id-Test', type: 'Default-Type', owner: 'Default-Owner'}),
    listOrdersBy: jest.fn(),
    linkOfferToOrder: jest.fn(),
    applyOfferToOrder: jest.fn(),
    getOrderById: jest.fn(),
    updateOrder: jest.fn()
}));

import 'regenerator-runtime/runtime';
import { clearMocksWithin } from './../../../libs/utils/testUtils';
import * as storage from './../src/interfaces/storage';
import * as sut from './../src/services/orders';
import { Notification } from './../../../libs/infrastructure';

jest.mock('./../../../libs/infrastructure');

describe('Orders service should', () => {
    afterEach(() => {
        Notification.mockClear();
        Notification.prototype.send.mockClear();
        clearMocksWithin(storage);
    });

    it('call storage.getAssociatedOrders with expected parameters when calling getAssociatedOrders', async () => {
        const expectedParameters = {
            orderOwnerId: 'orderId',
            query: 'query'
        };

        await sut.getAssociatedOrders(expectedParameters.orderOwnerId, expectedParameters.query);

        expect(storage.getAssociatedOrders)
            .toHaveBeenCalledWith(expectedParameters.orderOwnerId, expectedParameters.query);
        expect(storage.getAssociatedOrders)
            .toHaveBeenCalledTimes(1);
    });

    it('return result from storage.getAssociatedOrders when calling getAssociatedOrders', async () => {
        const expectedStorageResponse = {
            orderOwnerId: 'orderId',
            query: 'query'
        };

        storage.getAssociatedOrders.mockImplementation(() => expectedStorageResponse);

        const response = await sut.getAssociatedOrders({});

        expect(expectedStorageResponse).toBe(response);
    });

    it('call storage.saveOffer with expected parameters when calling applyOfferToOrder', async () => {
        const expectedParameters = {
            owner: 'OwnerId',
            status: 'new',
            order: 'purchase',
            offer: [],
            seo: { slug: 'test' }
        };

        await sut.applyOfferToOrder(expectedParameters);

        expect(storage.saveOffer)
            .toHaveBeenCalledWith(expectedParameters);
        expect(storage.saveOffer)
            .toHaveBeenCalledTimes(1);
    });

    it('send notification with expected parameters when calling applyOfferToOrder', async () => {
        const storageResult = { _id: 'A-Test-Id', order: 'An-Order-Id' };
        process.env.OFFER_SENT_TOPIC_ARN = 'Test-Arn';
        storage.saveOffer.mockImplementation(() => (storageResult));

        await sut.applyOfferToOrder({});

        expect(Notification).toHaveBeenCalledTimes(1);
        expect(Notification).toHaveBeenCalledWith(process.env.OFFER_SENT_TOPIC_ARN, storageResult, undefined, {
            deduplicationId: storageResult._id.toString(),
            groupId: storageResult.order
        });
        expect(Notification.prototype.send).toHaveBeenCalledTimes(1);
    });

    it('return result from storage.saveOffer when calling applyOfferToOrder', async () => {
        const expectedStorageResponse = { _id: 'Id-Test' };

        storage.saveOffer.mockImplementation(() => expectedStorageResponse);

        const response = await sut.applyOfferToOrder({});

        expect(expectedStorageResponse).toBe(response);
    });

    it('call storage.applyOfferToOrder with expected parameters when calling linkOfferToOrder', async () => {
        const expectedParameters = {
            orderId: 'orderId',
            offer: 'offer'
        };

        await sut.linkOfferToOrder(expectedParameters.orderId, expectedParameters.offer);

        expect(storage.applyOfferToOrder).toHaveBeenCalledWith(expectedParameters.orderId, expectedParameters.offer);
        expect(storage.applyOfferToOrder).toHaveBeenCalledTimes(1);
    })

    it('return result from storage.applyOfferToOrder when calling linkOfferToOrder', async () => {
        const expectedStorageResponse = {
            orderId: 'orderId',
            offer: 'offer'
        };

        storage.applyOfferToOrder.mockImplementation(() => expectedStorageResponse);

        const response = await sut.linkOfferToOrder({});

        expect(expectedStorageResponse).toBe(response);
    });

    it('call storage.saveOrder with expected parameters when calling createOrder', async () => {
        const expectedParameters = {
            _id: 'An-Id',
            title: 'A Title'
        };

        await sut.createOrder(expectedParameters);

        expect(storage.saveOrder).toHaveBeenCalledWith(expectedParameters);
        expect(storage.saveOrder).toHaveBeenCalledTimes(1);
    });

    it('send notification with expected parameters when calling createOrder', async () => {
        const expectedStorageResponse = { _id: 'An-Id', type: 'A-Type', owner: 'An-Owner' };
        storage.saveOrder.mockImplementation(() => expectedStorageResponse);
        process.env.ORDER_CREATED_TOPIC_ARN = 'Test-Arn';


        await sut.createOrder({});

        expect(Notification).toHaveBeenCalledTimes(1);
        expect(Notification).toHaveBeenCalledWith(process.env.ORDER_CREATED_TOPIC_ARN, expectedStorageResponse, {
            orderType: {
                DataType: 'String',
                StringValue: expectedStorageResponse.type
            }
        },
            {
                deduplicationId: expectedStorageResponse._id.toString(),
                groupId: expectedStorageResponse.owner
            });
    });

    it('call storage.listOrdersBy with expected parameters when calling listOrdersBy', async () => {
        const expectedParameters = {
            segmentId: 'segmentId',
            parameters: {
                parameter: 'A-Test-Parameter'
            }
        };

        await sut.listOrdersBy(expectedParameters.segmentId, expectedParameters.parameters);

        expect(storage.listOrdersBy).toHaveBeenCalledTimes(1);
        expect(storage.listOrdersBy).toHaveBeenCalledWith(expectedParameters.segmentId, expectedParameters.parameters);
    });

    it('return result from storage.listOrdersBy when calling listOrdersBy', async () => {
        const expectedResponse = {
            response: 'A-Test-Response'
        };
        storage.listOrdersBy.mockImplementation(() => expectedResponse);

        const result = await sut.listOrdersBy(undefined, undefined);

        expect(result).toMatchObject(expectedResponse);
    });
    
    it('return result from storage.saveOrder when calling createOrder', async () => {
        const expectedStorageResponse = { _id: 'An-Id', type: 'A-Type', owner: 'An-Owner' };

        storage.saveOrder.mockImplementation(() => expectedStorageResponse);

        const response = await sut.createOrder({});

        expect(expectedStorageResponse).toBe(response);
    });

    it('call storage.getOrderById with expected parameters when calling getOrderById', async () => {
        const expectedParameters = {
            orderId: 'orderId'
        };

        await sut.getOrderById(expectedParameters.orderId);

        expect(storage.getOrderById)
            .toHaveBeenCalledTimes(1);
        expect(storage.getOrderById)
            .toHaveBeenCalledWith(expectedParameters.orderId);
    });

    it('return result from storage.getOrderById when calling getOrderById', async () => {
        const expectedStorageResponse = { orderId: 'orderId' };

        storage.getOrderById.mockImplementation(() => expectedStorageResponse);

        const response = await sut.getOrderById({});

        expect(expectedStorageResponse).toBe(response);
    });

    it('call storage.updateOrder with expected parameters when calling updateOrder', async () => {
        const expectedParameters = {
            orderId: 'orderId',
            orderOwnerId: 'orderOwnerId',
            propertiesToUpdate: 'propertiesToUpdate'
        };

        await sut.updateOrder(expectedParameters.orderId, expectedParameters.orderOwnerId, expectedParameters.propertiesToUpdate);

        expect(storage.updateOrder)
            .toHaveBeenCalledTimes(1);
        expect(storage.updateOrder)
            .toHaveBeenCalledWith(expectedParameters.orderId, expectedParameters.orderOwnerId, expectedParameters.propertiesToUpdate);
    });

    it('return result from storage.updateOrder when calling updateOrder', async () => {
        const expectedStorageResponse = {
            orderId: 'orderId',
            orderOwnerId: 'orderOwnerId',
            propertiesToUpdate: 'propertiesToUpdate'
        };

        storage.updateOrder.mockImplementation(() => expectedStorageResponse);

        const response = await sut.updateOrder({});

        expect(expectedStorageResponse).toBe(response);
    });
});
import { SegmentModel } from './../../../../libs/models';
import { connectToDatabase } from './../../../../libs/infrastructure';

export const saveSegment = async (segmentToSave) => {
  await connectToDatabase();
  return SegmentModel.create(segmentToSave);
};

export const listSegments = async () => {
  await connectToDatabase();
  return SegmentModel.find().lean(true);
};

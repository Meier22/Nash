import { Handler } from './../../../../libs/infrastructure';
import { saveSegment } from './../services/segments';

export const handle = new Handler('Segment Creator')
  .withHttpPayloadParser()
  .handle(async (event, context) => {
      return await saveSegment(event.payload);
  });

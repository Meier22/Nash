import { Handler } from './../../../../libs/infrastructure';
import { listSegments } from './../services/segments';

export const handle = new Handler('Segment Retriever')
  .handle(async (event, context) => {
      return await listSegments();
  });

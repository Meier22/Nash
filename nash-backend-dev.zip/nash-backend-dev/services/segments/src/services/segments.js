import * as storage from './../interfaces/storage';

export const saveSegment = async (segmentToSave) => {
    return await storage.saveSegment(segmentToSave);
};

export const listSegments = async () => {
    return await storage.listSegments();
};

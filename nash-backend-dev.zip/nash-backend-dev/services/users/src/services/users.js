import * as storage from './../interfaces/storage';
import { NotFoundError } from '../../../../libs/infrastructure/errorHandlers';

export const saveUser = async (userToSave) => {
    return await storage.saveUser(userToSave);
};

export const updateUser = async (dataToUpdate, userId) => {
    const result = await storage.getUserById(userId);
    if (!result) throw new NotFoundError();
    return await storage.updateUser(dataToUpdate, userId);
};

export const getUserById = async (userId) => {
    const user = await storage.getUserById(userId);
    if (!user) throw new NotFoundError();
    return user;
};

export const getUserByEmail = async (userEmail) => {
    const user = await storage.getUserByEmail(userEmail);
    if (!user) throw new NotFoundError();
    return user;
};
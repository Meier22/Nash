import { Handler } from './../../../../libs/infrastructure';
import { updateUser } from './../services/users';

export const handle = new Handler('User Retriever')
  .withPathParametersPayloadParser()
  .withHttpPayloadParser()
  .handle(async (event, context) => {
    return await updateUser(event.payload, event.path.userId);
  });
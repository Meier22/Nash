import { Handler } from './../../../../libs/infrastructure';
import { getUserById } from './../services/users';

export const handle = new Handler('User Retriever')
  .withPathParametersPayloadParser()
  .handle(async (event, context) => {
    return await getUserById(event.path.userId);
  });
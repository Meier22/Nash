import { Handler } from './../../../../libs/infrastructure';
import { saveUser } from './../services/users';

export const handle = new Handler('User Creator')
  .withQueuePayloadParser()
  .handle(async (event, context) => {
      return await saveUser(event.message);
  });

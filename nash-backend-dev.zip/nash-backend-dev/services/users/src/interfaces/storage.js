import { UserModel } from './../../../../libs/models';
import { connectToDatabase } from './../../../../libs/infrastructure';

export const saveUser = async (userToSave) => {
  await connectToDatabase();
  return UserModel.create(userToSave);
};

export const updateUser = async (dataToUpdate, userId) => {
  await connectToDatabase();
  return UserModel.findOneAndUpdate({ _id: userId }, dataToUpdate, { new: true });
};

export const getUserById = async (userId) => {
  await connectToDatabase();
  return UserModel.findById(userId).lean(true);
};

export const getUserByEmail = async (userEmail) => {
  await connectToDatabase();
  return UserModel.findOne({ email: userEmail }).lean(true);
};

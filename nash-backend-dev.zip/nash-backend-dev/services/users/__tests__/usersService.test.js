jest.mock('./../src/interfaces/storage', () => ({
    __esModule: true,
    saveUser: jest.fn().mockReturnValue({ _id: 'Default-Test-Id' }),
    updateUser: jest.fn().mockReturnValue({ _id: 'Default-Id-Test' }),
    getUserById: jest.fn(),
    getUserByEmail: jest.fn()
}));

import 'regenerator-runtime/runtime';
import { clearMocksWithin } from './../../../libs/utils/testUtils';
import * as storage from './../src/interfaces/storage';
import * as sut from './../src/services/users';

jest.mock('./../../../libs/infrastructure');

describe('Users service should', () => {
    afterEach(() => {
        clearMocksWithin(storage);
    });

    it('call storage.saveUser with expected parameters when calling createUser', async () => {
        const expectedParameters = { _id: 'A-Test-Id' };

        await sut.saveUser(expectedParameters.userToSave);

        expect(storage.saveUser).toHaveBeenCalledWith(expectedParameters.userToSave);
        expect(storage.saveUser).toHaveBeenCalledTimes(1);
    });

    it('return result from storage.saveUser when calling createuser', async () => {
        const expectedStorageResponse = { _id: 'A-Test-Id' };

        storage.saveUser.mockImplementation(() => expectedStorageResponse);

        const response = await sut.saveUser({});

        expect(response).toBe(expectedStorageResponse);
    });

    it('call storage.updateUser with expected parameters when calling updateOne', async () => {
        const expectedParameters = {
            dataToUpdate: {
                firstName: 'firstName',
                lastName: 'lastName'
            },
            userId: 'userId'
        };

        await sut.updateUser(expectedParameters.dataToUpdate, expectedParameters.userId);

        expect(storage.updateUser).toHaveBeenCalledWith(expectedParameters.userId, expectedParameters.dataToUpdate);
        expect(storage.updateUser).toHaveBeenCalledTimes(1);
    });

    it('return result from storage.updateUser when calling updateOne', async () => {
        const expectedStorageResponse = { _id: 'A-Test-Id' };

        storage.updateUser.mockImplementation(() => expectedStorageResponse);

        const response = await sut.updateUser({});

        expect(response).toBe(expectedStorageResponse);
    });

    it('call storage.getUserById with expected parameters when calling getUserById', async () => {
        const expectedParameters = {
            userId: 'userId'
        };

        await sut.getUserById(expectedParameters.userId);

        expect(storage.getUserById).toHaveBeenCalledWith(expectedParameters.userId);
        expect(storage.getUserById).toHaveBeenCalledTimes(1);
    });

    it('return result from storage.getUserById when calling getUserById', async () => {
        const expectedStorageResponse = {
            userId: 'userId'
        };

        storage.getUserById.mockImplementation(() => expectedStorageResponse);

        const response = await sut.getUserById({});

        expect(response).toBe(expectedStorageResponse);
    });

    it('call storage.getUserByEmail with expected parameters when calling getUserByEmail', async () => {
        const expectedParameters = {
            userEmail: 'userEmail'
        };

        await sut.getUserByEmail(expectedParameters.userEmail);

        expect(storage.getUserByEmail).toHaveBeenCalledWith(expectedParameters.userEmail);
        expect(storage.getUserByEmail).toHaveBeenCalledTimes(1);
    });

    it('return result from storage.getUserByEmail when calling getUserByEmail', async () => {
        const expectedStorageResponse = {
            userEmail: 'userEmail'
        };

        storage.getUserByEmail.mockImplementation(() => expectedStorageResponse);

        const response = await sut.getUserByEmail({});

        expect(response).toBe(expectedStorageResponse);
    });
});
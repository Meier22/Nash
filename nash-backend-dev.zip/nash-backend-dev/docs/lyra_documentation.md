# *Documentación de Lyra*

## **Primeros pasos:** Pago simple
3 Etapas:
- Inicialización del formulario incrustado.
- Visualización del formulario incrustado
- Verificación del estado de la transacción al final del pago.

### **ETAPA 1: INICIALIZAR EL FORMULARIO**

Se debe inicializar el formulario generando un token de formulario (**formToken**) que resume todas las opciones vinculadas al pago.

- El formToken contiene la información necesaria para generar el formulario (precio, campo del formulario, opciones de pago, etc.). Puede alcanzar un tamaño de hasta 8 KB. **ES VALIDO POR 15 MINUTOS.**

#### **ETAPAS**
1-	Llamada al Servicio Web REST Charge/CreatePayment desde los servidores del vendedor.

  - #### **Crear el Form Token**
    - [Documentacion sobre autenticación](https://docs.lyra.com/es/rest/V4.0/api/kb/authentication.html). 
    - Cuando un comprador finaliza su compra en su sitio, usted debe validar su transacción en su servidor de vendedor comprobando, en particular, el monto, la moneda, el contenido del carrito, etc.

    - Tras estos controles, su servidor de vendedor debe llamar el Servicio Web Charge/CreatePayment para inicializar la transacción.

    - En respuesta, su servidor de vendedor recupera un formToken, objeto cifrado que permite inicializar el formulario incrustado con los datos de la transacción y de la configuración de la tienda.

    ```
    curl https://api.lyra.com/api-payment/V4/Charge/CreatePayment \
	  -X POST \
	  -H "Content-Type: application/json" \
	  -u 69876357:testpassword_DEMOPRIVATEKEY23G4475zXZQ2UA5x7M \
	-d '{
    "amount":   990,
    "currency": "EUR",
    "orderId":  "myOrderId-999999",
    "customer": {
        "email": "sample@example.com"
    }

- La respuesta será:

```
{
    "status": "SUCCESS",
    "_type": "V4/WebService/Response",
    "webService": "Charge/CreatePayment",
    "applicationProvider": "PAYZEN",
    "version": "V4",
    "applicationVersion": "4.1.0",
    "answer": {
        "formToken": "10WZlAWHOaSBuwIJhiMhyOZg218eyJhbW91bnQiOjk5MCwiY3VycmVuY3kiOiJFVVIiLCJtb2RlIjoiVEVTVCIsInZlcnNpb24iOjMsInNob3BOYW1lIjoiRGVtbyBzaG9wIiwiYnJhbmRQcmlvcml0eSI6WyJCQU5DT05UQUNUIiwiTUFTVEVSQ0FSRCIsIk1BU1RFUkNBUkRfREVCSVQiLCJWSVNBIiwiVklTQV9ERUJJVCIsIkNCIiwiRS1DQVJURUJMRVVFIiwiTUFFU1RSTyIsIlZJU0FfRUxFQ1RST04iXSwiY2F0ZWdvcmllcyI6eyJkZWJpdENyZWRpdENhcmRzIjp7ImFwcElkIjoiY2FyZHMiLCJwYXJhbSI6WyJFREVOUkVEIiwiQU1FWCIsIkNPTkVDUyIsIk1BU1RFUkNBUkRfREVCSVQiLCJESVNDT1ZFUiIsIlZJU0EiLCJWSVNBX0RFQklUIiwiU09ERVhPIiwiRElORVJTIiwiTUFFU1RSTyIsIkUtQ0FSVEVCTEVVRSIsIkNIUV9ERUoiLCJNQVNURVJDQVJEIiwiQkFOQ09OVEFDVCIsIkFQRVRJWiIsIlZJU0FfRUxFQ1RST04iLCJDQiJdfX0sImNhcmRzIjp7IkNPTkVDUyI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiQU1FWCI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7Im1heExlbmd0aCI6NH19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiRURFTlJFRCI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiTUFTVEVSQ0FSRF9ERUJJVCI6eyJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiRElTQ09WRVIiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIlZJU0EiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkRJTkVSUyI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiU09ERVhPIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJWSVNBX0RFQklUIjp7ImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJNQUVTVFJPIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJFLUNBUlRFQkxFVUUiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkNIUV9ERUoiOnsiZmllbGRzIjp7InNlY3VyaXR5Q29kZSI6eyJyZXF1aXJlZCI6ZmFsc2V9fSwiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIk1BU1RFUkNBUkQiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkJBTkNPTlRBQ1QiOnsiZmllbGRzIjp7InNlY3VyaXR5Q29kZSI6eyJyZXF1aXJlZCI6ZmFsc2UsImhpZGRlbiI6dHJ1ZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiVklTQV9FTEVDVFJPTiI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiQVBFVElaIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJERUZBVUxUIjp7ImZpZWxkcyI6eyJwYW4iOnsibWluTGVuZ3RoIjoxMCwibWF4TGVuZ3RoIjoxOSwidmFsaWRhdG9ycyI6WyJOVU1FUklDIiwiTFVITiJdLCJyZXF1aXJlZCI6dHJ1ZSwic2Vuc2l0aXZlIjp0cnVlLCJoaWRkZW4iOmZhbHNlLCJjbGVhck9uRXJyb3IiOmZhbHNlfSwiZXhwaXJ5RGF0ZSI6eyJyZXF1aXJlZCI6dHJ1ZSwic2Vuc2l0aXZlIjp0cnVlLCJoaWRkZW4iOmZhbHNlLCJjbGVhck9uRXJyb3IiOmZhbHNlfSwic2VjdXJpdHlDb2RlIjp7Im1pbkxlbmd0aCI6MywibWF4TGVuZ3RoIjo0LCJ2YWxpZGF0b3JzIjpbIk5VTUVSSUMiXSwicmVxdWlyZWQiOnRydWUsInNlbnNpdGl2ZSI6dHJ1ZSwiaGlkZGVuIjpmYWxzZSwiY2xlYXJPbkVycm9yIjp0cnVlfX19LCJDQiI6eyJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifX0sInBhc3NBY3RpdmF0ZWQiOnRydWUsImFwaVJlc3RWZXJzaW9uIjoiNC4wIiwiY291bnRyeSI6IkZSIn09202",
        "_type": "V4/Charge/PaymentForm"
    }
}
```


  
2-	Recepción del resultado que contiene el formToken.

#### *Casos de uso que definen cuando se inicializa el pago*

- Transmitir los datos del comprador:

Para transmitir el número de pedido, utilice el campo orderId:

```
{
  "orderId": "CX-1254"
}
```
- Transmitir el número de pedido:

    - El vendedor puede transmitir la dirección de facturación y los datos del comprador
    - Para ello, utilice el campo customer:
```
{
    "customer": 
    {
        "reference": "C2383333540",
        "email": " sample@example.net",
        "billingDetails": {
        "category": "PRIVATE",
        "title": "M",
        "firstName": "Laurent",
        "lastName": "DURANT",
        "streetNumber": "109",
        "address": "rue de l'innovation",
        "zipCode": "31670",
        "city": "LABEGE",
        "country": "FR",
        "phoneNumber": "0123456789",
        "cellPhoneNumber": "0623456789"
        }
    }
}
```
- Transmitir los datos de entrega:
    - El vendedor puede transmitir los datos de entrega del comprador (dirección, civilidad, número de teléfono, etc.).
    - Ejemplo para una entrega de tipo “Retiro en tienda”:
        
        - La dirección de entrega es la de la tienda.

        - La dirección de facturación no es la misma que la dirección de entrega.

        - El nombre del destinatario del envío es el de la dirección de facturación.



```
{
  "customer": {
    "shippingDetails": {
      "shippingMethod": "RECLAIM_IN_SHOP",
      "shippingSpeed": "STANDARD",
      "streetNumber": "230",
      "address": "avenue des Champs Elysées",
      "zipCode": "59170",
      "city": "CROIX",
      "country": "FR",
      "firstName": "Marie-Charlotte",
      "lastName": "GRIMALDI",
      "phoneNumber": "0328386789"
    }
  }
}
```

    - Ejemplo para una entrega de tipo “punto de retiro”:

        - La dirección de entrega es la del punto de retiro.

        - El nombre del punto de retiro se indica en la segunda línea de la dirección de entrega.

        - La dirección del punto de retiro se indica en la primera línea de la dirección de entrega.

        - El nombre del destinatario es el de la dirección de facturación.

        - La dirección de facturación no es la misma que la dirección de entrega.


```
{
  "customer": {
    "shippingDetails": {
      "shippingMethod": "RELAY_POINT",
      "shippingSpeed": "STANDARD",
      "streetNumber": "100",
      "address": "avenue du parc Barbieux",
      "address2": "Pressing du Parc",
      "zipCode": "59170",
      "city": "CROIX",
      "country": "FR",
      "firstName": "Martine",
      "lastName": "DURAND",
      "phoneNumber": "0328386789",
      "deliveryCompanyName": "Chronospost"
    }
  }
}
```


- Transmitir el contenido del carrito:

    - Al crear un pago, el vendedor puede transmitir el contenido del carrito del comprador.

    - Ejemplo para definir 2 artículos en el carrito:
    ```
        - `{
  "customer": {
    "shoppingCart": {
      "cartItemInfo": [
        {
          "productRef": "myRef1",
          "productAmount": "1200",
          "productLabel": "myLabel1",
          "productQty": "1"
        },
        {
          "productRef": "myRef2",
          "productAmount": "2400",
          "productLabel": "myLabel2",
          "productQty": "1"
        }
      ]
    }
  }
}`
    - *El campo cartItemInfo siempre se devuelve vacío en la respuesta.*

- Ofrecer el registro del medio de pago:
    - El vendedor puede ofrecer al comprador la posibilidad de facilitar sus compras solicitando el registro de sus datos bancarios en la plataforma de pago.
    -  la plataforma de pago asigna un token único al medio de pago y lo devuelve al sitio del comerciante a través del campo paymentMethodToken.
    - De esta manera, el comprador ya no tendrá que ingresar su método de pago en sus futuras compras.

    - **Le brinda un nivel de seguridad adicional a los pagos**
    
    - *Para ofrecer al comprador que registre su método de pago al momento del pago, utilice el campo formAction con el valor ASK_REGISTER_PAY*

        ```
        {
          "formAction": "ASK_REGISTER_PAY",
          "customer": {
            "email": " sample@example.net"
          }
        }
        ```
        
        -NOTAS: 
            
            - El campo email se vuelve obligatorio al registrar el medio de pago.

            - Cuando se muestre el formulario, aparecerá una casilla de verificación.

            - De forma predeterminada, esta casilla no está marcada.

            - Si el comprador acepta el registro de su medio de pago, debe marcar la casilla.

            - Si el pago es rechazado, no se registrará el medio de pago.


- Utilizar un medio de pago registrado
    
    - El vendedor puede transmitir el token que se debitará al inicializarse el pago.

    - Cuando se muestra el formulario, los campos **kr-pan** y **kr-expiry** se completarán automáticamente. El comprador solo tendrá que ingresar su código de seguridad (CVV) para finalizar su compra.

    - Para ello, simplemente transmita el token a debitar en el campo paymentMethodToken y asigne al campo formAction el valor PAYMENT.

    - Como este valor es el valor predeterminado, el campo **formAction** ya **no** es necesario.

        - `{
    "formAction" : "PAYMENT",
    "paymentMethodToken":"d3d9cc0d24a4400e9d123e9e1b8f1793",
}`




- Utilizar un medio de pago registrado sin  mostrar el formulario incrustado:

    - Cuando el comprador desea realizar una nueva compra, el comerciante puede, si lo desea, ofrecer la lista de los métodos de pago registrados para este cliente. Para hacerlo, muestra en su página el pan oculto y la fecha de validez devueltos al registrar el o los medios de pago. El comprador selecciona el medio de pago a utilizar y el vendedor inicializa el pago con el token asociado.

    - Para no mostrar el formulario incrustado, simplemente utilice el parámetro formAction con el valor **SILENT**:

        - `{
    "formAction" : "SILENT",
    "paymentMethodToken":"d3d9cc0d24a4400e9d123e9e1b8f1793",
}`

Para no mostrar el formulario incrustado, simplemente utilice el parámetro formAction con el valor SILENT:



#### LISTA DE PARÁMETROS A ENVIAR 
- *customer.email* : Dirección de correo electrónico del comprador

- *customer.billingDetails.identityCode:* Identificación nacional. Identifica de manera única a cada ciudadano en un país. CPF o CNPJ en Brasil.

- *customer.billingDetails.streetNumber:*   Número de calle de la dirección de facturación

- *customer.billingDetails.address:*  Dirección postal

- *customer.billingDetails.address2:*	Segunda línea de dirección.

- *customer.billingDetails.zipCode:* Código Postal.

- *customer.billingDetails.city:*  Ciudad

- *customer.billingDetails.state:* Estadp/ Región.

- *customer.billingDetails.country:* Código del país según ISO 3166 alpha-2

- *customer.billingDetails.phoneNumber:* Número de teléfono.

- *customer.billingDetails.cellPhoneNumber:* Número de celular.

**SHIPPING**

- *customer.shippingDetails.address:* Dirección Postal.

- *customer.shippingDetails.address2:* Segunda linea de dirección.

- *customer.shippingDetails.zipCode:* Codigo Postal

- *customer.shippingDetails.city:* Ciudad.

- *customer.shippingDetails.state:* Estado/ Region.

- *customer.shippingDetails.country:* Código del país según ISO 3166 alpha-2

- *customer.shippingDetails.shippingMethod:* Modo de entrega. Los nuevos valores específicos de 3DS2 estarán disponibles pronto

- *customer.shippingDetails.shippingSpeed:* Plazo de entrega. Los nuevos valores específicos de 3DS2 estarán disponibles pronto


### **ETAPA 2: MOSTRAR EL FORMULARIO**

- En la etapa anterior, creamos un formToken con la ayuda del Servicio Web REST Charge/CreatePayment. El formToken es utilizado por la biblioteca JavaScript para visualizar un formulario de pago.
- **Ejemplo de código**
  - Para insertar un formulario de pago, solo incluya el siguiente código (con el formToken previamente generado) :

```
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" 
   content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />  

  <!-- Javascript library. Should be loaded in head section -->
  <script 
   src="https://api.lyra.com/static/js/krypton-client/V4.0/stable/kr-payment-form.min.js" 
   kr-public-key="69876357:testpublickey_DEMOPUBLICKEY95me92597fd28tGD4r5" 
   kr-post-url-success="paid.html">
  </script>

  <!-- theme and plugins. should be loaded after the javascript library -->
  <!-- not mandatory but helps to have a nice payment form out of the box -->
  <link rel="stylesheet" 
  href="https://api.lyra.com/static/js/krypton-client/V4.0/ext/classic-reset.css">
 <script 
  src="https://api.lyra.com/static/js/krypton-client/V4.0/ext/classic.js">
 </script> 
</head>
<body>
  <!-- payment form -->
  <div class="kr-embedded" 
   kr-form-token="10WZlAWHOaSBuwIJhiMhyOZg218eyJhbW91bnQiOjk5MCwiY3VycmVuY3kiOiJFVVIiLCJtb2RlIjoiVEVTVCIsInZlcnNpb24iOjMsInNob3BOYW1lIjoiRGVtbyBzaG9wIiwiYnJhbmRQcmlvcml0eSI6WyJCQU5DT05UQUNUIiwiTUFTVEVSQ0FSRCIsIk1BU1RFUkNBUkRfREVCSVQiLCJWSVNBIiwiVklTQV9ERUJJVCIsIkNCIiwiRS1DQVJURUJMRVVFIiwiTUFFU1RSTyIsIlZJU0FfRUxFQ1RST04iXSwiY2F0ZWdvcmllcyI6eyJkZWJpdENyZWRpdENhcmRzIjp7ImFwcElkIjoiY2FyZHMiLCJwYXJhbSI6WyJFREVOUkVEIiwiQU1FWCIsIkNPTkVDUyIsIk1BU1RFUkNBUkRfREVCSVQiLCJESVNDT1ZFUiIsIlZJU0EiLCJWSVNBX0RFQklUIiwiU09ERVhPIiwiRElORVJTIiwiTUFFU1RSTyIsIkUtQ0FSVEVCTEVVRSIsIkNIUV9ERUoiLCJNQVNURVJDQVJEIiwiQkFOQ09OVEFDVCIsIkFQRVRJWiIsIlZJU0FfRUxFQ1RST04iLCJDQiJdfX0sImNhcmRzIjp7IkNPTkVDUyI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiQU1FWCI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7Im1heExlbmd0aCI6NH19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiRURFTlJFRCI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiTUFTVEVSQ0FSRF9ERUJJVCI6eyJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiRElTQ09WRVIiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIlZJU0EiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkRJTkVSUyI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiU09ERVhPIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJWSVNBX0RFQklUIjp7ImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJNQUVTVFJPIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJFLUNBUlRFQkxFVUUiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkNIUV9ERUoiOnsiZmllbGRzIjp7InNlY3VyaXR5Q29kZSI6eyJyZXF1aXJlZCI6ZmFsc2V9fSwiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIk1BU1RFUkNBUkQiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkJBTkNPTlRBQ1QiOnsiZmllbGRzIjp7InNlY3VyaXR5Q29kZSI6eyJyZXF1aXJlZCI6ZmFsc2UsImhpZGRlbiI6dHJ1ZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiVklTQV9FTEVDVFJPTiI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiQVBFVElaIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJERUZBVUxUIjp7ImZpZWxkcyI6eyJwYW4iOnsibWluTGVuZ3RoIjoxMCwibWF4TGVuZ3RoIjoxOSwidmFsaWRhdG9ycyI6WyJOVU1FUklDIiwiTFVITiJdLCJyZXF1aXJlZCI6dHJ1ZSwic2Vuc2l0aXZlIjp0cnVlLCJoaWRkZW4iOmZhbHNlLCJjbGVhck9uRXJyb3IiOmZhbHNlfSwiZXhwaXJ5RGF0ZSI6eyJyZXF1aXJlZCI6dHJ1ZSwic2Vuc2l0aXZlIjp0cnVlLCJoaWRkZW4iOmZhbHNlLCJjbGVhck9uRXJyb3IiOmZhbHNlfSwic2VjdXJpdHlDb2RlIjp7Im1pbkxlbmd0aCI6MywibWF4TGVuZ3RoIjo0LCJ2YWxpZGF0b3JzIjpbIk5VTUVSSUMiXSwicmVxdWlyZWQiOnRydWUsInNlbnNpdGl2ZSI6dHJ1ZSwiaGlkZGVuIjpmYWxzZSwiY2xlYXJPbkVycm9yIjp0cnVlfX19LCJDQiI6eyJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifX0sInBhc3NBY3RpdmF0ZWQiOnRydWUsImFwaVJlc3RWZXJzaW9uIjoiNC4wIiwiY291bnRyeSI6IkZSIn09202">

    <!-- payment form fields -->
    <div class="kr-pan"></div>
    <div class="kr-expiry"></div>
    <div class="kr-security-code"></div>

    <!-- payment form submit button -->
    <button class="kr-payment-button"></button>

    <!-- error zone -->
    <div class="kr-form-error"></div>
  </div>
</body>
</html>

```

#### **DESCRIPCION EN DETALLE DEL CODIGO ANTERIOR:**

- A - Cargar la biblioteca que construye el formulario de pago en el encabezado de la pagina, **_es importante que la biblitoeca cargue rapidamente, mucho antes que las demas bibliotecas JS utilizadas en nuestra pagina_**
```
 <!-- Javascript library. Should be loaded in head section -->
  <script 
   src="https://api.lyra.com/static/js/krypton-client/V4.0/stable/kr-payment-form.min.js" 
   kr-public-key="69876357:testpublickey_DEMOPUBLICKEY95me92597fd28tGD4r5" 
   kr-post-url-success="paid.html">
  </script>
```
- **IMPORTANTE** [Lista de parámetros de configuración disponibles, y plataformas compatibles](https://docs.lyra.com/es/rest/V4.0/javascript/features/reference.html)

- B - Aplicar un tema 
  - Para usar el tema predeterminado, simplemente incluya la siguiente hoja de estilo en la sección encabezado de su página:
  
```
 <!-- theme and plugins. should be loaded after the javascript library -->
  <!-- not mandatory but helps to have a nice payment form out of the box -->
  <link rel="stylesheet" 
  href="https://api.lyra.com/static/js/krypton-client/V4.0/ext/classic-reset.css">
 

 <script 
  src="https://api.lyra.com/static/js/krypton-client/V4.0/ext/classic.js">
 </script> 
```

- C - Introducción de los campos de formulario
```
  <!-- payment form -->
  <div class="kr-embedded" 
   kr-form-token="10WZlAWHOaSBuwIJhiMhyOZg218eyJhbW91bnQiOjk5MCwiY3VycmVuY3kiOiJFVVIiLCJtb2RlIjoiVEVTVCIsInZlcnNpb24iOjMsInNob3BOYW1lIjoiRGVtbyBzaG9wIiwiYnJhbmRQcmlvcml0eSI6WyJCQU5DT05UQUNUIiwiTUFTVEVSQ0FSRCIsIk1BU1RFUkNBUkRfREVCSVQiLCJWSVNBIiwiVklTQV9ERUJJVCIsIkNCIiwiRS1DQVJURUJMRVVFIiwiTUFFU1RSTyIsIlZJU0FfRUxFQ1RST04iXSwiY2F0ZWdvcmllcyI6eyJkZWJpdENyZWRpdENhcmRzIjp7ImFwcElkIjoiY2FyZHMiLCJwYXJhbSI6WyJFREVOUkVEIiwiQU1FWCIsIkNPTkVDUyIsIk1BU1RFUkNBUkRfREVCSVQiLCJESVNDT1ZFUiIsIlZJU0EiLCJWSVNBX0RFQklUIiwiU09ERVhPIiwiRElORVJTIiwiTUFFU1RSTyIsIkUtQ0FSVEVCTEVVRSIsIkNIUV9ERUoiLCJNQVNURVJDQVJEIiwiQkFOQ09OVEFDVCIsIkFQRVRJWiIsIlZJU0FfRUxFQ1RST04iLCJDQiJdfX0sImNhcmRzIjp7IkNPTkVDUyI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiQU1FWCI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7Im1heExlbmd0aCI6NH19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiRURFTlJFRCI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiTUFTVEVSQ0FSRF9ERUJJVCI6eyJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiRElTQ09WRVIiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIlZJU0EiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkRJTkVSUyI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiU09ERVhPIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJWSVNBX0RFQklUIjp7ImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJNQUVTVFJPIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJFLUNBUlRFQkxFVUUiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkNIUV9ERUoiOnsiZmllbGRzIjp7InNlY3VyaXR5Q29kZSI6eyJyZXF1aXJlZCI6ZmFsc2V9fSwiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIk1BU1RFUkNBUkQiOnsiY29weUZyb20iOiJjYXJkcy5ERUZBVUxUIn0sIkJBTkNPTlRBQ1QiOnsiZmllbGRzIjp7InNlY3VyaXR5Q29kZSI6eyJyZXF1aXJlZCI6ZmFsc2UsImhpZGRlbiI6dHJ1ZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiVklTQV9FTEVDVFJPTiI6eyJmaWVsZHMiOnsic2VjdXJpdHlDb2RlIjp7InJlcXVpcmVkIjpmYWxzZX19LCJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifSwiQVBFVElaIjp7ImZpZWxkcyI6eyJzZWN1cml0eUNvZGUiOnsicmVxdWlyZWQiOmZhbHNlfX0sImNvcHlGcm9tIjoiY2FyZHMuREVGQVVMVCJ9LCJERUZBVUxUIjp7ImZpZWxkcyI6eyJwYW4iOnsibWluTGVuZ3RoIjoxMCwibWF4TGVuZ3RoIjoxOSwidmFsaWRhdG9ycyI6WyJOVU1FUklDIiwiTFVITiJdLCJyZXF1aXJlZCI6dHJ1ZSwic2Vuc2l0aXZlIjp0cnVlLCJoaWRkZW4iOmZhbHNlLCJjbGVhck9uRXJyb3IiOmZhbHNlfSwiZXhwaXJ5RGF0ZSI6eyJyZXF1aXJlZCI6dHJ1ZSwic2Vuc2l0aXZlIjp0cnVlLCJoaWRkZW4iOmZhbHNlLCJjbGVhck9uRXJyb3IiOmZhbHNlfSwic2VjdXJpdHlDb2RlIjp7Im1pbkxlbmd0aCI6MywibWF4TGVuZ3RoIjo0LCJ2YWxpZGF0b3JzIjpbIk5VTUVSSUMiXSwicmVxdWlyZWQiOnRydWUsInNlbnNpdGl2ZSI6dHJ1ZSwiaGlkZGVuIjpmYWxzZSwiY2xlYXJPbkVycm9yIjp0cnVlfX19LCJDQiI6eyJjb3B5RnJvbSI6ImNhcmRzLkRFRkFVTFQifX0sInBhc3NBY3RpdmF0ZWQiOnRydWUsImFwaVJlc3RWZXJzaW9uIjoiNC4wIiwiY291bnRyeSI6IkZSIn09202">

    <!-- payment form fields -->
    <div class="kr-pan"></div>
    <div class="kr-expiry"></div>
    <div class="kr-security-code"></div>

    <!-- payment form submit button -->
    <button class="kr-payment-button"></button>

    <!-- error zone -->
    <div class="kr-form-error"></div>
  </div>
```
  -  El formulario debe definirse en un contenedor div de clase kr-embedded. El parámetro kr-form-token debe contener el formToken generado previamente durante la llamada al Servicio Web REST Charge/CreatePayment.

  - Los campos del formulario se insertan desde los contenedores especiales DIV. Se identifican a partir de las siguientes clases:


| PARAMETRO| DESCRIPCION|
| ----- | ---- |
| kr-pan	 | Número de tarjeta |
| kr-expiry	| Fecha de Expiración|
| kr-security-code	| Codigo de seguridad (CVV)|
| kr-first-installment-delay	| Numero de meses de diferido que se aplicaran a la primera cuota |
|kr-identity-document-type	| tipo de documento de identidad |
| kr-identity-document-number	| Numerop de documento de identidad |
| kr-card-holder-name	| Nombre titular de la tarjeta | 
| kr-card-holder-mail	| Mail de titular de la tarjeta | 

 **Si uno de los campos no está definido, o si el medio de pago requiere campos adicionales, el cliente Javascript los agregará (o eliminará) automáticamente. Definir los campos por su cuenta le permite forzar su orden de aparición.**



#### -D - Manejo de errores

  - Los errores se muestran automáticamente en el div de clase kr-form-error: (tambien se pueden manejar a mano [Manejo manual de errores](https://docs.lyra.com/es/rest/V4.0/javascript/features/js_error_management.html))
  
```
    <!-- error zone -->
    <div class="kr-form-error"></div>
```
#### -E - Boton de pago

  - Para validar su formulario, solo debe agregar un botón HTML clásico de clase kr-payment-button. La etiqueta se insertará automáticamente en el idioma correcto:

```
      <!-- payment form submit button -->
    <button class="kr-payment-button"></button>

```

#### **Integración con Vue / React / Angular:**
**REQUISITOS**:
- requiere el uso de la biblioteca **embedded-form-glue**.
    - Precarga de la biblioteca para permitir una visualización más rápida en redes lentas
    - Gestión de la configuración cuando la aplicación aún no está cargada
    - Agregar, eliminar y visualizar nuevamente el formulario de forma sencilla
- **LA BIBLIOTECA ESTA EN GITHUB https://github.com/lyra/embedded-form-glue**


### Trabajar en un entorno asíncrono.

Para permitirle integrar el formulario incrustado en un ambiente asíncrono, todos los eventos y métodos devuelven promesses.

A cada resolución, la promesa pasa un objeto al método .`then()` que puede contener dos propiedades:

`KR`: siempre se devuelve la referencia de la biblioteca de JavaScript, permitiendo encadenar promesas sea cual sea el contexto

`result`: el resultado de la operación, que puede ser indefinido u omitirse del objeto si no se devuelve ningún resultado

**EN EL SEIGUIENTE LINK SE DEJA UN EJEMPLO DE INTEGRACION CON REACT**:

  - [Enlace de Github]( https://github.com/lyra/embedded-form-glue/tree/master/examples/react/minimal-example)

### **ETAPA 3: VERIFICAR EL ESTADO DE LA TRANSACCIÓN:**

Cuando la transacción es aceptada o se alcanza el número de máximo de intentos, el cliente JavaScript realiza un POST del formulario de pago. Se desarrolla exactamente como si se tratara de un formulario HTML clásico. Usted obtiene la información de pago en los parámetros POST enviados a su servidor.

#### - ETAPAS:
      - 	El comprador ha hecho clic en el botón "pagar": envío del formulario desde el navegador del comprador a lso servidores de Lyra. Esta llamada es realizada automáticamente por el cliente JavaScript de Lyra.
      - Una vez procesada la transacción, los servidores de Lyra realizan una llamada a una URL previamente definida por nosotros. Se enviará el objeto Transaction completo para permitirle actualizar su sistema de información antes de regresar al navegador: es la IPN (Instant Payment Notification).
      -  Los servidores de Lyra reenvían el resultado del pago al cliente JavaScript.
      -	El cliente JavaScript publicará el formulario de pago en sus servidores.





## **Servicio REST- PRUEBA RAPIDA**

Crear una transacción: 
Methodo: POST

Punto de entrada:
https://api.lyra.com/api-payment/V4/Charge/CreatePayment

Documentación sobre servicio WEB en el palyground : https://docs.lyra.com/es/rest/V4.0/api/playground/Charge/CreatePayment/

Permite:
    
    Crear transaccion a partir de una tarjeta nueva

    Crear transaccion a partir de un TOKEN

### **AUTENTICACIÓN**

1- Cada llamada requiere una autenticación basada en el método HTTP Basic Authentication.

Método: HTTP Authorization 

Composición: palabra Basic seguido de una cadena codificada en base64 que contiene un nombre de usuario y una contraseña separadas por dos-puntos (:)
- El nombre de usuario es el identificador de la tienda: por ejemplo 28478261

#### **CARACTERÍSTICAS	DESCRIPCIÓN**

- **Usuario:**	Nombre de usuario que permite componer la cadena del encabezado Autorización.
- **Contraseña de prueba:**	Contraseña para componer la cadena "header Authorization" para las transacciones de prueba (con tarjetas de prueba).
- **Contraseña de producción:** Contraseña para componer la cadena "header Authorization" para las transacciones de producción (con tarjetas reales).

**Ejemplo de Request:**

`POST https://api.lyra.com/api-payment/V4/Charge/CreatePayment`

**HEADERS**:

`Authorization: Basic Njk4NzYzNTc6dGVzdHBhc3N3b3JkX0RFTU9QUklWQVRFS0VZMjNHNDQ3NXpYWlEyVUE1eDdN`

`Content-Type: application/json`

**BODY**
```
{
    "amount": 990,  

    "currency": "EUR",
    "paymentForms": [
        {
          "paymentMethodType": "CARD",
          "pan": "4970100000000055",
          "expiryMonth": "11",
          "expiryYear": "21",
          "securityCode": "123"
        }
      ]
    }
}
```

**Dos tipos de respuestas posibles (answer._type):**            

- *V4/Payment*:	Sin 3D Secure, la respuesta contiene el detalle de la transacción recién creada.

- *Charge/RedirectRequest:*	Se requiere autenticación fuerte (como 3D Secure). Es necesario redirigir al comprador.

- **_Mas info sobre estos dos tipos de respuestas en : https://docs.lyra.com/es/rest/V4.0/api/kb/pci_create_transaction_3ds.html_**

### **VERIFICAR ESTADO DE LA TRANSACCIÓN:**

- *PAID:* La transacción se ha pagado
- *RUNNING:* La transacción está a la espera de un evento.
- *UNPAID:* La transacción no se ha pagado.


